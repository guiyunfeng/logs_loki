
  # 日志可视化系统

  This is a code bundle for 日志可视化系统. The original project is available at https://www.figma.com/design/D8TeRZg7oJj8I3hchUyrFX/%E6%97%A5%E5%BF%97%E5%8F%AF%E8%A7%86%E5%8C%96%E7%B3%BB%E7%BB%9F.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  