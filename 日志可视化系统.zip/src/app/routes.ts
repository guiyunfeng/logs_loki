import { createBrowserRouter } from 'react-router';
import { LandingPage } from './components/LandingPage';
import { FlowPage } from './components/FlowPage';
import { SystemPage } from './components/SystemPage';
import { LogAnalyticsPage } from './components/LogAnalyticsPage';

export const router = createBrowserRouter([
  { path: '/', Component: LandingPage },
  { path: '/analytics', Component: LogAnalyticsPage },
  { path: '/flow', Component: FlowPage },
  { path: '/system', Component: SystemPage },
  { path: '*', Component: LandingPage },
]);